Temporary file until g8-scaffold will generate "test" directory
